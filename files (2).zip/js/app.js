// Main front-end logic for index.html
// Uses CONFIG from config.js (contains API_KEY you provided)

if (!window.CONFIG || !CONFIG.API_KEY) {
  console.warn("CONFIG.API_KEY is missing. Please check config.js.");
}

const state = {
  page: 1,
  pageSize: 20,
  query: '',
  region: 'us'
};

document.getElementById('year').textContent = new Date().getFullYear();
document.getElementById('load-more').addEventListener('click', () => {
  state.page++;
  loadMovies();
});
document.getElementById('search').addEventListener('keyup', (e) => {
  if (e.key === 'Enter') {
    state.query = e.target.value;
    state.page = 1;
    loadMovies(true);
  }
});

// Set signup CTA to affiliate link
const cta = document.getElementById('cta-signup');
cta.href = (typeof CONFIG !== 'undefined' && CONFIG.AFFILIATE_LINK) ? CONFIG.AFFILIATE_LINK : '#';

// Build API URL (adjust path names to match your provider)
function buildApiUrl(path, params = {}) {
  const base = (typeof CONFIG !== 'undefined' && CONFIG.API_BASE) ? CONFIG.API_BASE : 'https://api.example.com/v1';
  const url = new URL(base + path);
  const all = Object.assign({ api_key: (typeof CONFIG !== 'undefined' ? CONFIG.API_KEY : ''), region: state.region, page: state.page, pageSize: state.pageSize, query: state.query }, params);
  Object.keys(all).forEach(k => { if (all[k] !== undefined && all[k] !== '') url.searchParams.append(k, all[k]); });
  return url.toString();
}

async function loadMovies(replace = false) {
  const grid = document.getElementById('movies-grid');
  if (replace) grid.innerHTML = '';

  // Example endpoint (adjust to your real API): /discover
  const url = buildApiUrl('/discover');
  try {
    const res = await fetch(url);
    if (!res.ok) throw new Error('Failed to fetch movies: ' + res.status);
    const data = await res.json();

    const results = data.results || [];
    if (results.length === 0 && state.page === 1) {
      grid.innerHTML = '<p style="color:var(--muted)">No results</p>';
      return;
    }

    results.forEach(movie => {
      const a = document.createElement('a');
      a.className = 'card';
      a.href = `player.html?movie=${encodeURIComponent(movie.id)}`;
      a.innerHTML = `
        <img class="poster" src="${movie.poster || 'assets/placeholder.jpg'}" alt="${escapeHtml(movie.title || movie.name)}" />
        <div class="movie-title">${escapeHtml(movie.title || movie.name)}</div>
        <div class="movie-meta">${movie.year || ''} • ${movie.genre || ''}</div>
      `;
      grid.appendChild(a);
    });
  } catch (err) {
    console.error(err);
    grid.innerHTML = `<p style="color:var(--muted)">Unable to load content right now.</p>`;
  }
}

function escapeHtml(str=''){ return String(str).replace(/[&<>"']/g, (s)=>({ '&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[s]))}

// initial load
loadMovies();