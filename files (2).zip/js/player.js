// Player page logic
if (!window.CONFIG) console.warn("Please check config.js for API key and affiliate link.");

document.getElementById('year2').textContent = new Date().getFullYear();

function getQueryParam(name){
  const u = new URLSearchParams(location.search);
  return u.get(name);
}

async function loadMovie(id){
  if (!id) {
    document.getElementById('title').textContent = 'Movie not found';
    return;
  }

  const base = (typeof CONFIG !== 'undefined' && CONFIG.API_BASE) ? CONFIG.API_BASE : 'https://api.example.com/v1';
  const url = base + `/movie/${encodeURIComponent(id)}?api_key=${(typeof CONFIG !== 'undefined' ? CONFIG.API_KEY : '')}`;

  try {
    const res = await fetch(url);
    if (!res.ok) throw new Error('Failed to fetch movie details: ' + res.status);
    const movie = await res.json();

    document.title = movie.title || movie.name || 'Streamly Player';
    document.getElementById('pageTitle').textContent = `${movie.title || movie.name} — Watch`;
    document.getElementById('title').textContent = movie.title || movie.name;
    document.getElementById('overview').textContent = movie.overview || movie.description || '';

    const poster = movie.poster || 'assets/placeholder.jpg';
    document.getElementById('videoPlayer').poster = poster;

    const affiliate = (typeof CONFIG !== 'undefined' && CONFIG.AFFILIATE_LINK) ? CONFIG.AFFILIATE_LINK : '#';
    document.getElementById('affiliate-cta').href = affiliate;

    if (movie.stream_url) {
      const source = document.getElementById('video-source');
      source.src = movie.stream_url;
      document.getElementById('videoPlayer').load();
    }

  } catch (err) {
    console.error(err);
    document.getElementById('title').textContent = 'Unable to load content';
    document.getElementById('overview').textContent = '';
  }
}

const movieId = getQueryParam('movie');
loadMovie(movieId);